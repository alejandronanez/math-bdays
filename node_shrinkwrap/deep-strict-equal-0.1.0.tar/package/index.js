'use strict';
var __deepEqual = require('core-assert').__deepEqual;

module.exports = function (a, b) {
	return __deepEqual(a, b, true);
};
